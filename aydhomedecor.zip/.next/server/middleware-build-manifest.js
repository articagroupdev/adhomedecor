globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/n3GIC2XcfndOxeGoFI8gk/_buildManifest.js",
    "static/n3GIC2XcfndOxeGoFI8gk/_ssgManifest.js",
    "static/n3GIC2XcfndOxeGoFI8gk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0iq1i69206cyl.js",
    "static/chunks/10vhn3z1il7jp.js",
    "static/chunks/3fhjoe1h5iwpi.js",
    "static/chunks/turbopack-2caae_jq-wtaa.js"
  ]
};
