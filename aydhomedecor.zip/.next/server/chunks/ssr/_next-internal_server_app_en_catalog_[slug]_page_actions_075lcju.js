module.exports=[39159,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_en_catalog_%5Bslug%5D_page_actions_075lcju.js.map