module.exports=[87644,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_catalogo_buscar_page_actions_0tfplkn.js.map