module.exports=[59925,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_producto_%5Bslug%5D_page_actions_1w6mpp9.js.map