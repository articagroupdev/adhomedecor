module.exports=[66247,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_en_faq_page_actions_1v591np.js.map