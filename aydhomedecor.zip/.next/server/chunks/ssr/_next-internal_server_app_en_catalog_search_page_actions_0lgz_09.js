module.exports=[47501,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_en_catalog_search_page_actions_0lgz_09.js.map