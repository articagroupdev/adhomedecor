module.exports=[79376,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_catalogo_%5Bslug%5D_page_actions_1pi53fj.js.map