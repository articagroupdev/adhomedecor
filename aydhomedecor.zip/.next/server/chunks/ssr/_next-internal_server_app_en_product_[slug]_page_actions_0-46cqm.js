module.exports=[27562,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_en_product_%5Bslug%5D_page_actions_0-46cqm.js.map