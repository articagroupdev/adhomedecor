module.exports=[82937,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_en_contact_page_actions_1sydzcs.js.map