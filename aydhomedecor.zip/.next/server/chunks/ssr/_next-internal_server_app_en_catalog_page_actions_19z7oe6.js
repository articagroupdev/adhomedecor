module.exports=[66521,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_en_catalog_page_actions_19z7oe6.js.map